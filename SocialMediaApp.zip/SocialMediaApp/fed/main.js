function login(){
    window.location.href='login.html'
}

function signup(){
    window.location.href='register.html'
}